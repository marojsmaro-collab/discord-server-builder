# Idea Nudge

Idea Nudge is an Android app for saving ideas, projects, and things you want to do, with recurring reminders to check your list.

## Features

- Save ideas locally on your phone.
- Mark ideas complete or delete them.
- Choose reminders every 10, 15, 20, or 30 minutes.
- Tap a reminder notification to open the app.
- Restore reminder scheduling after a device restart.

## Build the APK

The GitHub Actions workflow named **Build Idea Nudge APK** builds a debug APK.

1. Open the repository's **Actions** tab.
2. Open the latest **Build Idea Nudge APK** run.
3. Download the **idea-nudge-debug-apk** artifact.
4. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Reminder permissions

Allow notifications when Android asks. For more reliable timing, use the **Enable reliable reminders** button in the app and allow exact alarms if Android offers that setting. Some phone battery-management settings may delay reminders.

## Privacy

Your ideas are stored locally in the app's private preferences. The app does not upload your list to a server.
