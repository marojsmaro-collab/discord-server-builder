package com.maro.ideanudge

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("idea_nudge", Context.MODE_PRIVATE)
        val ideas = try { JSONArray(prefs.getString("ideas", "[]")) } catch (_: Exception) { JSONArray() }
        val active = (0 until ideas.length()).count { !ideas.optJSONObject(it).optBoolean("done") }
        val body = if (active > 0) {
            "You have $active saved ideas. Open Idea Nudge and pick one to work on."
        } else {
            "Open Idea Nudge and add something you want to make, try, or do."
        }
        val openApp = PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(context, "idea_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("A quick reminder for you")
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(42, notification)
        scheduleNext(context)
    }

    companion object {
        fun scheduleNext(context: Context) {
            val prefs = context.getSharedPreferences("idea_nudge", Context.MODE_PRIVATE)
            val minutes = prefs.getInt("interval", 15).coerceIn(10, 30)
            val intent = Intent(context, ReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, 42, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val whenMillis = System.currentTimeMillis() + minutes * 60_000L
            try {
                if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pending)
                } else if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pending)
                } else {
                    alarm.setExact(AlarmManager.RTC_WAKEUP, whenMillis, pending)
                }
            } catch (_: SecurityException) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pending)
            }
        }
    }
}
