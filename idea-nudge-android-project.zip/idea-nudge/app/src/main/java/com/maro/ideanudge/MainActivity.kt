package com.maro.ideanudge

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("idea_nudge", Context.MODE_PRIVATE) }
    private lateinit var listContainer: LinearLayout
    private lateinit var countLabel: TextView
    private lateinit var intervalSpinner: Spinner

    private val bg = Color.rgb(13, 16, 25)
    private val panel = Color.rgb(25, 30, 44)
    private val accent = Color.rgb(108, 112, 255)
    private val muted = Color.rgb(165, 174, 197)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        createNotificationChannel()
        buildScreen()
        requestNotificationPermission()
        ReminderReceiver.scheduleNext(this)
    }

    override fun onResume() {
        super.onResume()
        if (::listContainer.isInitialized) ReminderReceiver.scheduleNext(this)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(label("IDEA NUDGE", 13, accent, true))
        content.addView(space(8))
        content.addView(label("Don't lose your next big idea.", 27, white, true))
        content.addView(space(6))
        content.addView(label("Save what you want to build, try, learn, and do.", 14, muted))
        content.addView(space(22))

        val reminderCard = card()
        reminderCard.addView(label("REMINDER INTERVAL", 12, muted, true))
        reminderCard.addView(space(8))
        intervalSpinner = Spinner(this)
        val intervals = listOf("Every 10 minutes", "Every 15 minutes", "Every 20 minutes", "Every 30 minutes")
        intervalSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervals)
        val savedInterval = prefs.getInt("interval", 15)
        intervalSpinner.setSelection(listOf(10, 15, 20, 30).indexOf(savedInterval).coerceAtLeast(0))
        intervalSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val minutes = listOf(10, 15, 20, 30)[position]
                if (prefs.getInt("interval", 15) != minutes) {
                    prefs.edit().putInt("interval", minutes).apply()
                    ReminderReceiver.scheduleNext(this@MainActivity)
                }
            }
        }
        reminderCard.addView(intervalSpinner)
        reminderCard.addView(space(8))
        val permissionButton = button("Enable reliable reminders", accent)
        permissionButton.setOnClickListener { requestReminderPermissions() }
        reminderCard.addView(permissionButton)
        content.addView(reminderCard)
        content.addView(space(20))

        content.addView(label("YOUR IDEAS", 12, muted, true))
        content.addView(space(8))
        countLabel = label("", 14, muted)
        content.addView(countLabel)
        content.addView(space(10))

        val inputCard = card()
        val ideaInput = EditText(this).apply {
            hint = "What are you excited to make or do?"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(35, 41, 58))
            minLines = 2
            maxLines = 4
        }
        inputCard.addView(ideaInput, LinearLayout.LayoutParams(-1, -2))
        inputCard.addView(space(10))
        val addButton = button("+  Add to my list", accent)
        addButton.setOnClickListener {
            val value = ideaInput.text.toString().trim()
            if (value.isNotEmpty()) {
                val ideas = loadIdeas()
                ideas.put(JSONObject().put("text", value).put("done", false))
                saveIdeas(ideas)
                ideaInput.setText("")
                renderIdeas()
            }
        }
        inputCard.addView(addButton)
        content.addView(inputCard)
        content.addView(space(14))

        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listContainer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("Your list is saved on this phone.", 12, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(root)
        renderIdeas()
    }

    private fun renderIdeas() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val ideas = loadIdeas()
        val active = (0 until ideas.length()).count { !ideas.optJSONObject(it).optBoolean("done") }
        countLabel.text = "$active active  •  ${ideas.length()} total"

        if (ideas.length() == 0) {
            val empty = card()
            empty.addView(label("Nothing here yet. Add the first thing you're excited about.", 14, muted))
            listContainer.addView(empty)
            return
        }

        for (i in 0 until ideas.length()) {
            val item = ideas.optJSONObject(i) ?: continue
            val done = item.optBoolean("done")
            val row = card()
            val ideaText = label(item.optString("text"), 15, if (done) muted else white, !done)
            if (done) ideaText.paintFlags = ideaText.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            row.addView(ideaText)
            row.addView(space(8))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val toggle = button(if (done) "Undo" else "Done", Color.rgb(48, 130, 105))
            toggle.setOnClickListener {
                item.put("done", !done)
                saveIdeas(ideas)
                renderIdeas()
            }
            val delete = button("Delete", Color.rgb(150, 61, 77))
            delete.setOnClickListener {
                val updated = JSONArray()
                for (j in 0 until ideas.length()) if (j != i) updated.put(ideas.getJSONObject(j))
                saveIdeas(updated)
                renderIdeas()
            }
            actions.addView(toggle, LinearLayout.LayoutParams(0, dp(44), 1f))
            actions.addView(spaceHorizontal(8))
            actions.addView(delete, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(actions)
            listContainer.addView(row)
            listContainer.addView(space(8))
        }
    }

    private fun loadIdeas(): JSONArray = try {
        JSONArray(prefs.getString("ideas", "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun saveIdeas(ideas: JSONArray) {
        prefs.edit().putString("ideas", ideas.toString()).apply()
    }

    private fun requestReminderPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val alarms = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!alarms.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
        ReminderReceiver.scheduleNext(this)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(
                "idea_reminders", "Idea reminders",
                android.app.NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = "Reminds you to check your saved ideas"
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(value: String, color: Int) = Button(this).apply {
        text = value
        textSize = 14f
        setTextColor(white)
        setBackgroundColor(color)
        isAllCaps = false
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun spaceHorizontal(width: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(width), 1)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
